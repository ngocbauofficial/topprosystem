﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;

namespace TopProSystem.Areas.MasterSetting.Models
{
    public class ClassificationCode
    {
        public const string CLASSIFICATTIONCODE001 = "001";
        public const string CLASSIFICATTIONCODE002 = "002";
        public const string CLASSIFICATTIONCODE003 = "003";
        public const string CLASSIFICATTIONCODE004 = "004";
        public const string CLASSIFICATTIONCODE005 = "005";
        public const string CLASSIFICATTIONCODE006 = "006";
        public const string CLASSIFICATTIONCODE007 = "007";
        public const string CLASSIFICATTIONCODE008 = "008";
        public const string CLASSIFICATTIONCODE009 = "009";
        public const string CLASSIFICATTIONCODE010 = "010";
        public const string CLASSIFICATTIONCODE011 = "011";
        public const string CLASSIFICATTIONCODE012 = "012";
        public const string CLASSIFICATTIONCODE013 = "013";
        public const string CLASSIFICATTIONCODE014 = "014";
        public const string CLASSIFICATTIONCODE015 = "015";
        public const string CLASSIFICATTIONCODE016 = "016";
        public const string CLASSIFICATTIONCODE017 = "017";
        public const string CLASSIFICATTIONCODE018 = "018";
        public const string CLASSIFICATTIONCODE019 = "019";
        public const string CLASSIFICATTIONCODE020 = "020";
        public const string CLASSIFICATTIONCODE021 = "021";
        public const string CLASSIFICATTIONCODE022 = "022";
        public const string CLASSIFICATTIONCODE023 = "023";
        public const string CLASSIFICATTIONCODE024 = "024";
        public const string CLASSIFICATTIONCODE025 = "025";
        public const string CLASSIFICATTIONCODE026 = "026";
        public const string CLASSIFICATTIONCODE027 = "027";
        public const string CLASSIFICATTIONCODE028 = "028";
        public const string CLASSIFICATTIONCODE029 = "029";
        public const string CLASSIFICATTIONCODE030 = "030";
        public const string CLASSIFICATTIONCODE031 = "031";
        public const string CLASSIFICATTIONCODE032 = "032";
        public const string CLASSIFICATTIONCODE033 = "033";
        public const string CLASSIFICATTIONCODE034 = "034";
        public const string CLASSIFICATTIONCODE035 = "035";
        public const string CLASSIFICATTIONCODE036 = "036";
    }
}