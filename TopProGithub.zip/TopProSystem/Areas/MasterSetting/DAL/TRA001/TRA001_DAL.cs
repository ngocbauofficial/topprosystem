﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using TopProSystem.Areas.MasterSetting.Models;

namespace TopProSystem.Areas.MasterSetting.DAL.TRA001
{
    public class TRA001_DAL
    {
 

      
    }
}